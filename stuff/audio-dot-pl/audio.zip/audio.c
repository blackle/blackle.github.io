#include <dlfcn.h>
#include <stdio.h>
#include "audio.pl.gz.h"

#define LOAD_BUF_SIZE 1024

void _start(){
    //manual loading :3
    void *libc = dlopen( "libc.so", RTLD_LAZY );

    //load defs from libc
    void (*exit)(int) = dlsym(libc, "exit");
    void (*close)(int) = dlsym(libc, "close");
    void (*dup2)(int, int) = dlsym(libc, "dup2");
    int (*write)(int, const void *, size_t) = dlsym(libc, "write");
    //int (*wait)(int *) = dlsym(libc, "wait");
    void (*execvp)(const char *, ... ) = dlsym(libc, "execlp");
    int (*fork)() = dlsym(libc, "fork");
    void (*pipe)(int *) = dlsym(libc, "pipe");
    //int (*read)(int, const void *, size_t) = dlsym(libc, "read");

    //define some pipes
    int gzip_to_perl[2];
    int source_to_gzip[2];
    int perl_to_aplay[2];
    int pid;
    
	(*pipe)(perl_to_aplay);
    
    pid = (*fork)();
	if(pid == 0){
		//close read end
		(*close)(perl_to_aplay[0]);

		(*pipe)(gzip_to_perl);
		
		pid = (*fork)();
		if(pid == 0){
			//close pipe we don't need
			(*close)(perl_to_aplay[1]);
			//close read end
			(*close)(gzip_to_perl[0]);
			
		    (*pipe)(source_to_gzip);
			
			pid = (*fork)();
			if(pid == 0){
				//parent gzip feeder
				//close pipe we don't need
				(*close)(gzip_to_perl[1]);
				
				//close read end
				(*close)(source_to_gzip[0]);
			
				(*write)(source_to_gzip[1], audio_pl_gz, audio_pl_gz_len);
		
				//done writing
				(*close)(source_to_gzip[1]);

				//(*wait)(NULL);
				exit(0);
			} else {
				//gzip
				//close write end
				(*close)(source_to_gzip[1]);
				
		        //copy pipe to stdin
		        (*dup2)(source_to_gzip[0], 0);
		        //copy pipe to stdout
		        (*dup2)(gzip_to_perl[1], 1);
		        
		        (*execvp)("gzip", "gzip", "-d", NULL);
			}
		} else {
			//perl
			//close write end
			(*close)(gzip_to_perl[1]);
			
	        //copy pipe to stdin
	        (*dup2)(gzip_to_perl[0], 0);
	        //copy pipe to stdout
	        (*dup2)(perl_to_aplay[1], 1);
	        
	        (*execvp)("perl", "perl", NULL);
		}
	} else {
		//aplay
		
		//close write end
		(*close)(perl_to_aplay[1]);
		
		//copy pipe to stdin
		(*dup2)(perl_to_aplay[0], 0);
	
		(*execvp)("aplay", "aplay", "-q", "-c", "1", "-r", "22050", "-f", "S16_LE", NULL);
		//pulseaudio fallback
		(*execvp)("paplay", "paplay", "-p", "--raw", "--channels=1", "--rate=22050", NULL);
	}
}
